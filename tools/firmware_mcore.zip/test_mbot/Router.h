#pragma once

#include <Arduino.h>

typedef void (*MsgHandler)(byte *buffer);

class Router
{
public:
	Router();

	void setup();
	void loop();

	void regHandler(byte id, MsgHandler handler);

private:
	void moveData(byte from, byte to);
	void dispatch();

private:
	MsgHandler handlerList[0x80];
	byte buffer[64];
	byte index;
};
