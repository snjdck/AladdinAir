#include "SerialIO.h"

union TypeCast{
	uint8_t byteVal[8];
	uint16_t shortVal[4];
    uint32_t longVal[2];
    float floatVal[2];
	double doubleVal;
};

SerialIO::SerialIO(byte *buffer)
:buffer(buffer)
{}

uint16_t SerialIO::readuShort(int offset)
{
	TypeCast cast;
	for(int i=0; i<2; ++i)
		cast.byteVal[i] = buffer[offset+i];
	return cast.shortVal[0];
}

float SerialIO::readFloat(int offset)
{
	TypeCast cast;
	for(int i=0; i<4; ++i)
		cast.byteVal[i] = buffer[offset+i];
	return cast.floatVal[0];
}
