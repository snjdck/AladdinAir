#pragma once

#include <Arduino.h>

class SerialIO
{
public:
	SerialIO(byte *buffer);
	uint16_t	readuShort	(int offset);
	float		readFloat	(int offset);

private:
	byte *buffer;
};
